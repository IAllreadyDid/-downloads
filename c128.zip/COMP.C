/***************************************************************************** 
DOS style comp command for the commodore 128, CP/M 3+ mode
While tested on the C-128, should work on any cp/m system.    
Does not support wildcard args, (see copy.c for example) 

4/29/99 - Ken Mauro  
******************************************************************************/



/* comp80-1.c                  compare two files  */

/* compile with c80, link using as80.com */


#include "printf.c"
#define BLOCKSIZ 512



main(argc,argv)
int argc; 
char *argv[];
{
        static int f1,f2,c,d;
        static int block = 0, lflag = 0, charn = -1;

        if (argv[1][0] == '-' && (argv[1][1] == 'l' || argv[1][1] == 'L')) {
                lflag++; argc--; argv++; 
                }
                if (argc != 3) {
                        printf("Usage: comp [-l] file1 file2\n"); 
                        exit(); 
                        }
        f1 = file(argv[1]);
        f2 = file(argv[2]);

        while(1) {
                if (++charn == BLOCKSIZ){ 
                    block++ ;charn = 0; 
                    }
                c = getc(f1); d = getc(f2);
                if (c == d) {
                        if (c < 0) {
                            if (lflag <= 1) 
                                printf("%s and %s  - %d bytes compared ok.\n",
                                argv[1],argv[2], ((block*BLOCKSIZ)+charn) );
                        exit(); 
                        }
                continue; 
                }

                if (c < 0) {printf("%s is shorter.\n",argv[1]); exit(); }
                if (d < 0) {printf("%s is shorter.\n",argv[2]); exit(); }
                if (lflag) {
                        printf("%s char %d block %d  = %3o; %s = %3o\n",
                                        argv[1],charn,block,c,argv[2],d);
                        lflag = 2;
                        continue; }

                printf("%s and %s  differ at offset %d.\n",
                                argv[1], argv[2], ((block*BLOCKSIZ)+charn) );

                exit(); 

                }
 
}

file(fname)
char *fname;
{      int i;
        i = fopen(fname,"rb");
        if (i > 0) return i;
        printf("Can't open: %s\n",fname);
        exit();
}

