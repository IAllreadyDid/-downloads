
#include "printf.c"

main() {
	printf("Hello, World. \n\n\n");
        printf("Press any key to continue..\n");	
	
	getchar();
	}


f.c"

main() {
	printf("Hello, World. \n\n\n");
        printf("Press any key to continue..\n");	
	
	getc