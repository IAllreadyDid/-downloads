
 /* Declarations of DM86 functions, In(put) and Ret(urn) types commented */
 /* int-2 byte integer, nil-nothing, s-string, s16-string oflength 16    */
 /* e.g.  i=DISP(10),  SETF(retstrng,setstrng),  UPDF(retstrng)		 */

 extern int CLRSCR();  /*  Clear the screen..............I nt, Ret-int    */
 extern int CLSDIS();  /*  Close file, reset CRT.........In-nil, Ret-int  */
 extern     CURS()  ;  /*  Turn on/off cursor............In-int, Ret-s1   */
 extern int DISPD() ;  /*  Show display on screen........In-int, Ret-int  */
 extern int ENDF()  ;  /*  Returns terminating char......In-int, Ret-int  */
 extern	    GETF()  ;  /*  Get input from field..........In-nil, Ret-s    */
 extern int INITDM();  /*  Initialize **Max len 255**....In-s,   Ret-int  */
 extern int NXTF()  ;  /*  Relative field positioning....In-int, Ret-int  */
 extern int POSF()  ;  /*  Absolute field pos............In-int, Ret-int  */
 extern int OPNDIS();  /*  Open display file, set CRT....In-s,   Ret-int  */
 extern int PUTF()  ;  /*  Write data to field...........In-s,   Ret-int  */
 extern int RESF()  ;  /*  Resume input stored prev......In-int, Ret-s    */
 extern     RETDM() ;  /*  Return CRT capabilities.......In-nil, Ret-s16  */
 extern     RETF()  ;  /*  Return field capabilities.....In-nil, Ret-s16  */
 extern     SETF()  ;  /*  Set/reset field attrs.........In-s,   Ret-s    */
 extern     UPDF()  ;  /*  Update field input............In-nil, Ret-s    */
